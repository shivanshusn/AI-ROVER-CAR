#pragma once
#include <Arduino.h>
namespace Ultrasonic {
void begin();
void update();
bool enabled();
float distanceCm();        // <0 = invalid
const char* state();       // disabled/ok/warn/stop/fault
void applyLimit(int& left, int& right);  // forward only; no rear protection
}
