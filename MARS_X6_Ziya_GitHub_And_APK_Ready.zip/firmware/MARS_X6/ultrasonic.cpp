#include "ultrasonic.h"
#include "config.h"
#include "pins.h"
#if ULTRASONIC_ENABLED
namespace {
volatile uint32_t t0 = 0, width = 0; volatile bool got = false;
float dist = -1; uint32_t lastValid = 0, lastTrig = 0;
void IRAM_ATTR isr() { if (digitalRead(Pins::US_ECHO)) t0 = micros(); else { width = micros() - t0; got = true; } }
bool fault() { return millis() - lastValid > 500; }
}
namespace Ultrasonic {
void begin() { pinMode(Pins::US_TRIG, OUTPUT); digitalWrite(Pins::US_TRIG, LOW); pinMode(Pins::US_ECHO, INPUT); attachInterrupt(Pins::US_ECHO, isr, CHANGE); lastValid = millis(); }
void update() {
  if (got) { got = false; float d = width / 58.0f; if (d >= 2 && d <= 400) { dist = d; lastValid = millis(); } else dist = -1; }
  if (millis() - lastTrig >= 60) { lastTrig = millis(); digitalWrite(Pins::US_TRIG, HIGH); delayMicroseconds(10); digitalWrite(Pins::US_TRIG, LOW); }
}
bool enabled() { return true; }
float distanceCm() { return fault() ? -1 : dist; }
const char* state() {
  if (fault()) return "fault";
  if (dist < 0) return "ok";
  return dist <= US_STOP_CM ? "stop" : (dist <= US_WARN_CM ? "warn" : "ok");
}
void applyLimit(int& l, int& r) {
  const char* s = state();
  bool block = !strcmp(s, "stop") || (!strcmp(s, "fault") && US_FAULT_BLOCKS_FORWARD);
  bool slow = !strcmp(s, "warn");
  if (block) { if (l > 0) l = 0; if (r > 0) r = 0; }
  else if (slow) { if (l > 0) l /= 2; if (r > 0) r /= 2; }
}
}
#else
namespace Ultrasonic {
void begin() {} void update() {} bool enabled() { return false; }
float distanceCm() { return -1; } const char* state() { return "disabled"; }
void applyLimit(int&, int&) {}
}
#endif
