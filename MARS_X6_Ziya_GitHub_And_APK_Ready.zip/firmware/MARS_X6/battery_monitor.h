#pragma once
#include <Arduino.h>
namespace Battery {
enum Level : uint8_t { OK, LOW_V, CRITICAL };
void begin();
void update();
float voltage();        // pack voltage
float cellVoltage();    // pack / BATT_CELLS
int percent();          // APPROXIMATE only
Level level();
const char* levelName();
}
