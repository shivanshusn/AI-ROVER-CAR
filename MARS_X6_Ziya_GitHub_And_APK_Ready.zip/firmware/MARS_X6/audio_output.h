#pragma once
#include <Arduino.h>
namespace Audio {
void begin();
void update();
bool enabled();
}
