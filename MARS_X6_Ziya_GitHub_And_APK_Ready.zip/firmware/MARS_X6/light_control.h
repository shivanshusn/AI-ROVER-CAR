#pragma once
#include <Arduino.h>
namespace Lights {
void begin();
void update();
void set(uint8_t idx, bool on);  // 0=FL, 1=FR, 2=RL, 3=RR
void setHead(bool on);
void setTail(bool on);
void setAll(bool on);
void setHazard(bool on);
void setMode(uint8_t m);         // 0=normal, 1=hazard, 2=police, 3=disco
uint8_t mode();
uint8_t mask();
bool hazard();
}
