#pragma once
#include <Arduino.h>
// Horn has NO GPIO: the speaker (phone speaker now, PAM amp later) plays the horn sound.
// ESP32 only keeps the horn state (with auto-off) so every client/audio module sees it in telemetry.
namespace Horn {
void begin();
void update();
void on(uint32_t ms);
void off();
bool isOn();
}
