#pragma once
#define FW_VERSION "2.1.0-1xL298N"
#define PROTOCOL_VERSION 1

// ---- Network (Single-Phone & Dual-Phone Hotspot Mode) ----
#define NET_AP 0      // Pure AP Mode (Zero glitch, rock-solid http://192.168.4.1)
#define NET_STA 1
#define NET_AP_STA 2
#define NET_MODE NET_AP_STA

#define AP_SSID "MARS-X6"
#define AP_PASS "mars12345"             // Min 8 chars
#define AP_CHANNEL 6
#define WIFI_SSID "F15"
#define WIFI_PASS "12348765"
#define PAIRING_KEY ""                  // Empty = No pairing key lockout! Instant drive!
#define MDNS_NAME "mars-x6"
#define HTTP_PORT 80
#define WIFI_RETRY_MS 8000

// ---- Safety (Auto-Armed on Boot + Generous Timeout so Throttle Never Cuts Out!) ----
#define HEARTBEAT_TIMEOUT_MS 2500
#define ESTOP_HW_ENABLED 0
#define ESTOP_TRIGGER_LEVEL HIGH

// ---- Single L298N 6-Wheel Motors (3 Left on Ch-A, 3 Right on Ch-B) ----
// Standard 6-pin L298N header: ENA=25, IN1=16, IN2=17, IN3=32, IN4=33, ENB=14
#define MOTOR_PWM_FREQ 1000
#define MOTOR_PWM_BITS 8
#define MOTOR_MIN_PWM 95                // Strong starting torque so 6 BO motors move immediately!
#define MOTOR_RAMP_STEP 50              // Instant throttle response (no sluggish lag)
#define MOTOR_RAMP_INTERVAL_MS 10
#define MOTOR_VOLT_CAP_ENABLED 0        // Unlocked 12V Full Power by default (User can adjust 6V-12V in UI)
#define MOTOR_RATED_V 12.0f
#define MOTOR_DRIVER_DROP_V 2.0f
#define MOTOR_FALLBACK_CAP_PCT 100

// ---- Differential Turning Ratio on 1x L298N ----
#define TURN_INNER_FRONT_RATIO 0.25f
#define TURN_INNER_REAR_RATIO  0.25f

// ---- Submersible Water / Spray Pump ----
#define PUMP_ENABLED 1
#define PUMP_PWM_FREQ 1000
#define PUMP_PWM_BITS 8
#define PUMP_RATED_V 6.0f
#define PUMP_SUPPLY_V 0.0f
#define PUMP_MAX_RUN_MS 45000

// ---- Dual Servos (Cargo/Arm + Camera Pan) ----
#define SERVO_FREQ 50
#define SERVO_BITS 16
#define SERVO_MIN_US 500
#define SERVO_MAX_US 2400
#define SERVO_STEP_INTERVAL_MS 15
#define CARGO_CLOSED_DEG 10
#define CARGO_OPEN_DEG 105
#define CARGO_STEP_DEG 4
#define CAM_CENTER_DEG 90
#define CAM_MIN_DEG 20
#define CAM_MAX_DEG 160
#define CAM_STEP_DEG 3
#define CAM_BUTTON_STEP_DEG 12

// ---- Lights / Horn ----
#define HAZARD_PERIOD_MS 350
#define HORN_MAX_MS 2500

// ---- Battery: 3S1P ----
#define BATT_CELLS 3
#define BATT_DIV_RATIO 4.70f
#define BATT_CAL_FACTOR 1.00f
#define BATT_LOW_CELL_V 3.50f
#define BATT_CRIT_CELL_V 3.20f
#define BATT_SAMPLE_MS 250

// ---- Optional modules ----
#define ULTRASONIC_ENABLED 0
#define US_WARN_CM 60
#define US_STOP_CM 25
#define US_FAULT_BLOCKS_FORWARD 0
#define AUDIO_ENABLED 0
