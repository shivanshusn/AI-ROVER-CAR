#pragma once
#include <Arduino.h>
namespace Pump {
void begin();
void update();
void on(int pct, uint32_t ms);   // pct 10..100 of allowed max, ms 0 = PUMP_MAX_RUN_MS
void off();
bool isOn();
int percent();
bool enabled();
void setBatteryVoltage(float packV);
}
