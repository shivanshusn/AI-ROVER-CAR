#pragma once
#include <Arduino.h>
namespace Comm {
void begin();
void update();
}
