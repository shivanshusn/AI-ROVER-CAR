#include "servo_control.h"
#include "config.h"
#include "pins.h"
#include "pwm_compat.h"

namespace {
float cargoCur = CARGO_CLOSED_DEG, cargoTgt = CARGO_CLOSED_DEG;
float camCur = CAM_CENTER_DEG, camTgt = CAM_CENTER_DEG;
int camMn = CAM_MIN_DEG, camMx = CAM_MAX_DEG;
uint32_t autoMs = 0, openedAt = 0, lastStep = 0;
bool wantOpen = false;

void out(uint8_t pin, float deg) {
  deg = constrain(deg, 0.0f, 180.0f);
  uint32_t us = SERVO_MIN_US + (uint32_t)(deg * (SERVO_MAX_US - SERVO_MIN_US) / 180.0f);
  PwmCompat::write(pin, pin == Pins::SERVO_CARGO ? 3 : 4, (us * 65535UL) / 20000UL);
}
float approach(float c, float t, float s) {
  if (fabsf(t - c) <= s) return t;
  return c < t ? c + s : c - s;
}
}

namespace Servos {
void begin() {
  PwmCompat::attach(Pins::SERVO_CARGO, 3, SERVO_FREQ, SERVO_BITS);
  PwmCompat::attach(Pins::SERVO_CAM, 4, SERVO_FREQ, SERVO_BITS);
  out(Pins::SERVO_CARGO, cargoCur);
  out(Pins::SERVO_CAM, camCur);
}
void update() {
  uint32_t now = millis();
  if (now - lastStep < SERVO_STEP_INTERVAL_MS) return;
  lastStep = now;
  if (cargoCur != cargoTgt) { cargoCur = approach(cargoCur, cargoTgt, CARGO_STEP_DEG); out(Pins::SERVO_CARGO, cargoCur); }
  if (camCur != camTgt) { camCur = approach(camCur, camTgt, CAM_STEP_DEG); out(Pins::SERVO_CAM, camCur); }
  if (wantOpen && autoMs > 0 && cargoCur == cargoTgt && now - openedAt > autoMs) cargoClose();
}
void cargoOpen() { wantOpen = true; cargoTgt = CARGO_OPEN_DEG; openedAt = millis(); }
void cargoClose() { wantOpen = false; cargoTgt = CARGO_CLOSED_DEG; }
void cargoSetAngle(float deg) { cargoTgt = constrain(deg, 0.0f, 180.0f); wantOpen = (cargoTgt > 45.0f); openedAt = millis(); }
void setAutoCloseMs(uint32_t ms) { autoMs = ms; openedAt = millis(); }
uint32_t autoCloseMs() { return autoMs; }
const char* cargoState() {
  if (cargoCur == cargoTgt) return wantOpen ? "open" : "closed";
  return wantOpen ? "opening" : "closing";
}
float cargoAngle() { return cargoCur; }
void camPan(float d) { camTgt = constrain(d, (float)camMn, (float)camMx); }
void camNudge(float d) { camPan(camTgt + d); }
void camCenter() { camPan(constrain((float)CAM_CENTER_DEG, (float)camMn, (float)camMx)); }
bool camSetLimits(int mn, int mx) {
  if (mn < 0 || mx > 180 || mn >= mx) return false;
  camMn = mn; camMx = mx; camPan(camTgt); return true;
}
float camAngle() { return camCur; }
int camMin() { return camMn; }
int camMax() { return camMx; }
}
