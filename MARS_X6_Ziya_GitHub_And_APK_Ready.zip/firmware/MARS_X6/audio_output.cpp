#include "audio_output.h"
#include "config.h"
#include "pins.h"
// Phase 1: disabled. GPIO33 reserved. Implement once the exact PAM module is known.
namespace Audio {
void begin() {
#if AUDIO_ENABLED
  pinMode(Pins::AUDIO, OUTPUT); digitalWrite(Pins::AUDIO, LOW);
#endif
}
void update() {}
bool enabled() { return AUDIO_ENABLED; }
}
