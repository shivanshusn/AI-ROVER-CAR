// MARS-X6 Rover - Phase 1 firmware (ESP32 Arduino Core 3.x)
// Library needed: ArduinoJson v7 (Library Manager). Everything else is in the ESP32 core.
#include "config.h"
#include "pins.h"
#include "motor_control.h"
#include "servo_control.h"
#include "light_control.h"
#include "horn_control.h"
#include "pump_control.h"
#include "battery_monitor.h"
#include "safety_manager.h"
#include "communication.h"
#include "ultrasonic.h"
#include "audio_output.h"

static void applySupply() {
  float v = Battery::voltage();
  Motor::setSupplyVoltage(v);
  Pump::setBatteryVoltage(v);
}

void setup() {
  Serial.begin(115200);
  Motor::begin();      // safe outputs first
  Pump::begin();
  Lights::begin();
  Horn::begin();
  Servos::begin();
  Battery::begin();
  applySupply();
  Safety::begin();
  Ultrasonic::begin();
  Audio::begin();
  Comm::begin();

  Serial.println();
  Serial.printf("MARS-X6 fw %s proto %d\n", FW_VERSION, PROTOCOL_VERSION);
  Serial.printf("Self-check: motors OFF, pump OFF, disarmed | pack %.2fV (%.2fV/cell, %s) | motor cap %d%%\n",
                Battery::voltage(), Battery::cellVoltage(), Battery::levelName(), Motor::voltageCapPct());
#if NET_MODE == NET_AP
  Serial.printf("Direct mode: connect phone to Wi-Fi '%s', open http://192.168.4.1\n", AP_SSID);
#endif
  Serial.println("Serial bench test: {\"v\":1,\"cmd\":\"status\"}");
}

void loop() {
  Comm::update();
  Safety::update();
  Motor::update();
  Pump::update();
  Servos::update();
  Lights::update();
  Horn::update();
  Battery::update();
  applySupply();
  Ultrasonic::update();
  Audio::update();
}
