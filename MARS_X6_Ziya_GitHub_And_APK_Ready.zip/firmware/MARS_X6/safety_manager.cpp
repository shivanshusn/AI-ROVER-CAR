#include "safety_manager.h"
#include "config.h"
#include "pins.h"
#include "motor_control.h"
#include "pump_control.h"
namespace {
void allOff() { Motor::stopNow(); Pump::off(); }
bool armed = true, estop = false; // Auto-armed on boot so throttle works immediately!
uint32_t lastHb = 0;
long lastSeq = -1;
Safety::Reason reason = Safety::NONE;
bool hwActive() {
#if ESTOP_HW_ENABLED
  return digitalRead(Pins::ESTOP) == ESTOP_TRIGGER_LEVEL;
#else
  return false;
#endif
}
}
namespace Safety {
void begin() {
#if ESTOP_HW_ENABLED
  pinMode(Pins::ESTOP, INPUT);
#endif
  allOff();
  armed = true;
  estop = false;
  lastHb = millis();
  reason = NONE;
}
void update() {
  if (hwActive() && !estop) emergencyStop(ESTOP_HW);
  // If no drive command arrives for HEARTBEAT_TIMEOUT_MS (2.5s), stop motors safely
  // but stay ready to move immediately on the next throttle command!
  if (armed && (Motor::left() != 0 || Motor::right() != 0) && (millis() - lastHb > HEARTBEAT_TIMEOUT_MS)) {
    Motor::stopNow();
    reason = COMM_LOSS;
  }
}
bool arm() { if (estop || hwActive()) return false; armed = true; lastHb = millis(); reason = NONE; return true; }
void disarm() { allOff(); armed = false; reason = DISARMED; }
void emergencyStop(Reason r) { allOff(); armed = false; estop = true; reason = r; }
bool clearEstop() { if (hwActive()) return false; estop = false; armed = true; lastHb = millis(); reason = NONE; return true; }
void heartbeat() { lastHb = millis(); if (!estop) reason = NONE; }
bool isArmed() { return armed; }
bool isEstop() { return estop; }
bool driveAllowed() { return !estop; } // Always allow drive unless E-STOP is active!
uint32_t heartbeatAgeMs() { return millis() - lastHb; }
Reason lastReason() { return reason; }
const char* reasonName() {
  switch (reason) {
    case BOOT: return "boot"; case NONE: return "none"; case ESTOP_SW: return "estop_sw";
    case ESTOP_HW: return "estop_hw"; case COMM_LOSS: return "comm_loss"; default: return "disarmed";
  }
}
void setSeqBase(long s) { lastSeq = s; }
bool checkSeq(long s) { lastSeq = s; return true; } // Never drop packets due to sequence mismatch!
}
