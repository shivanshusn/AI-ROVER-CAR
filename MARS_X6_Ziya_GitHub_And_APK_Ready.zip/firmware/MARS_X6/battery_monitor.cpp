#include "battery_monitor.h"
#include "config.h"
#include "pins.h"
namespace {
float v = 0; bool first = true; uint32_t last = 0;
void sample() {
  uint32_t mv = 0;
  for (int i = 0; i < 8; i++) mv += analogReadMilliVolts(Pins::BATT_ADC);
  float vin = (mv / 8.0f) / 1000.0f * BATT_DIV_RATIO * BATT_CAL_FACTOR;
  v = first ? vin : v * 0.8f + vin * 0.2f;
  first = false;
}
}
namespace Battery {
void begin() { pinMode(Pins::BATT_ADC, INPUT); analogSetPinAttenuation(Pins::BATT_ADC, ADC_11db); sample(); }
void update() { uint32_t n = millis(); if (n - last >= BATT_SAMPLE_MS) { last = n; sample(); } }
float voltage() { return v; }
float cellVoltage() { return v / BATT_CELLS; }
int percent() {
  static const float tv[] = {3.30f, 3.50f, 3.60f, 3.70f, 3.80f, 3.90f, 4.00f, 4.10f, 4.20f};
  static const int tp[] = {0, 10, 20, 35, 50, 65, 80, 90, 100};
  float c = cellVoltage();
  if (c <= tv[0]) return 0;
  if (c >= tv[8]) return 100;
  for (int i = 0; i < 8; i++)
    if (c < tv[i + 1]) return tp[i] + (int)((c - tv[i]) / (tv[i + 1] - tv[i]) * (tp[i + 1] - tp[i]));
  return 100;
}
Level level() { float c = cellVoltage(); return c < BATT_CRIT_CELL_V ? CRITICAL : (c < BATT_LOW_CELL_V ? LOW_V : OK); }
const char* levelName() { Level l = level(); return l == CRITICAL ? "critical" : (l == LOW_V ? "low" : "ok"); }
}
