#include "horn_control.h"
#include "config.h"
namespace { bool active = false; uint32_t until = 0; }
namespace Horn {
void begin() {}
void on(uint32_t ms) { if (ms == 0 || ms > HORN_MAX_MS) ms = HORN_MAX_MS; active = true; until = millis() + ms; }
void off() { active = false; }
void update() { if (active && (int32_t)(millis() - until) >= 0) off(); }
bool isOn() { return active; }
}
