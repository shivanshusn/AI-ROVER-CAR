#pragma once
#include <Arduino.h>
namespace Servos {
void begin();
void update();
void cargoOpen();
void cargoClose();
void cargoSetAngle(float deg);
void setAutoCloseMs(uint32_t ms);
const char* cargoState();
float cargoAngle();
void camPan(float deg);
void camNudge(float deltaDeg);
void camCenter();
bool camSetLimits(int mn, int mx);
float camAngle();
int camMin();
int camMax();
uint32_t autoCloseMs();
}
