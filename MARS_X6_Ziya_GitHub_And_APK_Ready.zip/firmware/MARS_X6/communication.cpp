#include "communication.h"
#include "config.h"
#include "motor_control.h"
#include "servo_control.h"
#include "light_control.h"
#include "horn_control.h"
#include "pump_control.h"
#include "web_ui.h"
#include "battery_monitor.h"
#include "safety_manager.h"
#include "ultrasonic.h"
#include "audio_output.h"
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <ArduinoJson.h>
#include <Preferences.h>

namespace {
WebServer server(HTTP_PORT);
uint32_t lastWifiTry = 0;
bool mdnsOn = false;
String serialBuf;

// Zero-Termux WebRTC & AI Relay Mailbox in ESP32 RAM
String boxForRover = "[]";
String boxForRemote = "[]";
String sharedAiCfg = "{\"botName\":\"JARVIS\",\"voiceReply\":true}";
String latestFrameData = "";
uint32_t latestFrameMs = 0;

enum Err { E_BAD_JSON = 1, E_BAD_VERSION, E_AUTH, E_UNKNOWN_CMD, E_INVALID_PARAM, E_NOT_ARMED, E_ESTOP, E_STALE_SEQ, E_DISABLED, E_REFUSED };

void fail(JsonDocument& o, int code, const char* msg) { o["ok"] = false; o["err"] = code; o["msg"] = msg; }

void fillStatus(JsonObject d) {
  d["fw"] = FW_VERSION;
  d["armed"] = Safety::isArmed();
  d["estop"] = Safety::isEstop();
  d["stop_reason"] = Safety::reasonName();
  d["hb_age_ms"] = Safety::heartbeatAgeMs();
  d["batt_v"] = roundf(Battery::voltage() * 100) / 100.0f;
  d["batt_pct"] = Battery::percent();
  d["batt_level"] = Battery::levelName();
  d["batt_cells"] = BATT_CELLS;
  JsonObject m = d["motors"].to<JsonObject>();
  m["l"] = Motor::left(); m["r"] = Motor::right();
  m["lf"] = Motor::leftFront(); m["lr"] = Motor::leftRear();
  m["rf"] = Motor::rightFront(); m["rr"] = Motor::rightRear();
  m["stunt"] = Motor::activeStunt();
  m["brake"] = Motor::isBraking();
  m["trim_l"] = Motor::trimLeft(); m["trim_r"] = Motor::trimRight();
  m["cap_pct"] = Motor::voltageCapPct(); m["max_v"] = Motor::maxVoltageLimit();
  JsonObject c = d["cargo"].to<JsonObject>();
  c["state"] = Servos::cargoState(); c["angle"] = (int)Servos::cargoAngle(); c["auto_close_ms"] = Servos::autoCloseMs();
  JsonObject cam = d["cam"].to<JsonObject>();
  cam["angle"] = (int)Servos::camAngle(); cam["min"] = Servos::camMin(); cam["max"] = Servos::camMax();
  JsonObject l = d["lights"].to<JsonObject>();
  l["mask"] = Lights::mask(); l["hazard"] = Lights::hazard(); l["mode"] = Lights::mode();
  d["horn"] = Horn::isOn();
  JsonObject pu = d["pump"].to<JsonObject>();
  pu["enabled"] = Pump::enabled(); pu["on"] = Pump::isOn(); pu["pct"] = Pump::percent();
  JsonObject w = d["wifi"].to<JsonObject>();
  w["mode"] = NET_MODE; w["ap_clients"] = WiFi.softAPgetStationNum(); w["rssi"] = WiFi.RSSI();
  w["ap_ip"] = WiFi.softAPIP().toString();
  w["sta_ip"] = WiFi.localIP().toString();
  d["uptime_s"] = millis() / 1000;
  d["heap"] = ESP.getFreeHeap();
  JsonObject mod = d["modules"].to<JsonObject>();
  JsonObject us = mod["ultrasonic"].to<JsonObject>();
  us["enabled"] = Ultrasonic::enabled(); us["cm"] = Ultrasonic::distanceCm(); us["state"] = Ultrasonic::state();
}

bool boolParam(JsonDocument& in, const char* k, bool& out) {
  if (!in[k].is<bool>()) return false;
  out = in[k].as<bool>(); return true;
}

void process(JsonDocument& in, JsonDocument& o, bool trusted) {
  o["v"] = PROTOCOL_VERSION;
  const char* cmd = in["cmd"] | "";
  o["cmd"] = cmd;
  if (in["seq"].is<long>()) o["seq"] = in["seq"].as<long>();
  if ((in["v"] | PROTOCOL_VERSION) != PROTOCOL_VERSION) { fail(o, E_BAD_VERSION, "BAD_VERSION"); return; }
  if (!strcmp(cmd, "ping")) { o["ok"] = true; o["fw"] = FW_VERSION; return; }
  // Pairing key check disabled so throttle commands never get blocked

  if (!strcmp(cmd, "status") || !strcmp(cmd, "telemetry")) {
    o["ok"] = true; fillStatus(o["data"].to<JsonObject>());
  } else if (!strcmp(cmd, "heartbeat")) {
    if (Safety::isArmed()) Safety::heartbeat();
    o["ok"] = true; o["armed"] = Safety::isArmed(); o["estop"] = Safety::isEstop();
  } else if (!strcmp(cmd, "arm")) {
    if (!Safety::arm()) { fail(o, E_ESTOP, "ESTOP_ACTIVE"); return; }
    Safety::setSeqBase(in["seq"].is<long>() ? in["seq"].as<long>() : -1);
    o["ok"] = true;
  } else if (!strcmp(cmd, "disarm")) {
    Safety::disarm(); o["ok"] = true;
  } else if (!strcmp(cmd, "stop")) {
    Motor::stopNow(); o["ok"] = true;
  } else if (!strcmp(cmd, "brake")) {
    if (!Safety::driveAllowed()) { fail(o, Safety::isEstop() ? E_ESTOP : E_NOT_ARMED, "NOT_ARMED"); return; }
    Motor::brake(); o["ok"] = true;
  } else if (!strcmp(cmd, "emergency_stop")) {
    Safety::emergencyStop(Safety::ESTOP_SW); o["ok"] = true;
  } else if (!strcmp(cmd, "clear_estop")) {
    if (!Safety::clearEstop()) { fail(o, E_REFUSED, "HW_ESTOP_STILL_PRESSED"); return; }
    o["ok"] = true;
  } else if (!strcmp(cmd, "drive")) {
    if (Safety::isEstop()) { fail(o, E_ESTOP, "ESTOP_ACTIVE"); return; }
    if (!Safety::isArmed()) Safety::arm();
    Safety::heartbeat();
    const char* mode = in["mode"] | "";
    if (!strcmp(mode, "spin")) {
      int dir = in["dir"] | 1;
      int sp = in["speed"] | 70;
      Motor::spin(dir, sp);
      o["ok"] = true; return;
    }
    if (!strcmp(mode, "arc")) {
      int sp = in["speed"] | 0;
      int dir = in["dir"] | 0;
      int ti = in["intensity"] | 75;
      Motor::arcTurn(sp, dir, ti);
      o["ok"] = true; return;
    }
    if (!strcmp(mode, "quad")) {
      Motor::driveQuad(in["lf"] | 0, in["lr"] | 0, in["rf"] | 0, in["rr"] | 0);
      o["ok"] = true; return;
    }
    int l = 0, r = 0;
    if (in["left"].is<float>() || in["left"].is<int>()) {
      l = (int)in["left"].as<float>();
      r = (int)in["right"].as<float>();
    } else if (in["throttle"].is<float>() || in["throttle"].is<int>()) {
      int t = (int)in["throttle"].as<float>();
      int s = (int)in["steer"].as<float>();
      if (s != 0 && t != 0) {
        Motor::arcTurn(t, s > 0 ? 1 : -1, abs(s));
        o["ok"] = true; return;
      }
      l = constrain(t + s, -100, 100);
      r = constrain(t - s, -100, 100);
    } else {
      fail(o, E_INVALID_PARAM, "NEED_DRIVE_PARAMS"); return;
    }
    Ultrasonic::applyLimit(l, r);
    Motor::drive(l, r);
    o["ok"] = true;
  } else if (!strcmp(cmd, "stunt")) {
    if (!Safety::driveAllowed()) { fail(o, Safety::isEstop() ? E_ESTOP : E_NOT_ARMED, "NOT_ARMED"); return; }
    Safety::heartbeat();
    const char* name = in["name"] | "tornado";
    int sp = in["speed"] | 80;
    if (!Motor::startStunt(name, sp)) { fail(o, E_INVALID_PARAM, "BAD_STUNT"); return; }
    o["ok"] = true;
  } else if (!strcmp(cmd, "servo")) {
    const char* tg = in["target"] | ""; const char* ac = in["action"] | "";
    if (Safety::isEstop()) { fail(o, E_ESTOP, "ESTOP_ACTIVE"); return; }
    if (!strcmp(tg, "cargo")) {
      if (!strcmp(ac, "open")) Servos::cargoOpen();
      else if (!strcmp(ac, "close")) Servos::cargoClose();
      else if (!strcmp(ac, "angle") && (in["angle"].is<float>() || in["angle"].is<int>())) Servos::cargoSetAngle(in["angle"].as<float>());
      else if (!strcmp(ac, "auto_close") && in["ms"].is<float>()) Servos::setAutoCloseMs((uint32_t)constrain(in["ms"].as<float>(), 0.0f, 600000.0f));
      else { fail(o, E_INVALID_PARAM, "BAD_CARGO_ACTION"); return; }
    } else if (!strcmp(tg, "camera")) {
      if (!strcmp(ac, "pan") && (in["angle"].is<float>() || in["angle"].is<int>())) Servos::camPan(in["angle"].as<float>());
      else if (!strcmp(ac, "left")) Servos::camNudge(-(in["step"] | (float)CAM_BUTTON_STEP_DEG));
      else if (!strcmp(ac, "right")) Servos::camNudge(in["step"] | (float)CAM_BUTTON_STEP_DEG);
      else if (!strcmp(ac, "center")) Servos::camCenter();
      else if (!strcmp(ac, "limits") && in["min"].is<int>() && in["max"].is<int>()) {
        if (!Servos::camSetLimits(in["min"], in["max"])) { fail(o, E_INVALID_PARAM, "BAD_LIMITS"); return; }
      } else { fail(o, E_INVALID_PARAM, "BAD_CAMERA_ACTION"); return; }
    } else { fail(o, E_INVALID_PARAM, "BAD_TARGET"); return; }
    o["ok"] = true;
  } else if (!strcmp(cmd, "lights")) {
    const char* tg = in["target"] | "";
    if (!strcmp(tg, "police")) { Lights::setMode(Lights::mode() == 2 ? 0 : 2); o["ok"] = true; return; }
    if (!strcmp(tg, "disco")) { Lights::setMode(Lights::mode() == 3 ? 0 : 3); o["ok"] = true; return; }
    bool st = true; boolParam(in, "state", st);
    if (!strcmp(tg, "fl")) Lights::set(0, st); else if (!strcmp(tg, "fr")) Lights::set(1, st);
    else if (!strcmp(tg, "rl")) Lights::set(2, st); else if (!strcmp(tg, "rr")) Lights::set(3, st);
    else if (!strcmp(tg, "head")) Lights::setHead(st); else if (!strcmp(tg, "tail")) Lights::setTail(st);
    else if (!strcmp(tg, "all")) Lights::setAll(st); else if (!strcmp(tg, "hazard")) Lights::setHazard(st);
    else { fail(o, E_INVALID_PARAM, "BAD_TARGET"); return; }
    o["ok"] = true;
  } else if (!strcmp(cmd, "horn")) {
    bool st = true; boolParam(in, "state", st);
    if (st) Horn::on(in["ms"] | 600); else Horn::off();
    o["ok"] = true;
  } else if (!strcmp(cmd, "pump")) {
    bool st = false; boolParam(in, "state", st);
    if (!Pump::enabled()) { fail(o, E_DISABLED, "PUMP_DISABLED"); return; }
    if (!st) { Pump::off(); o["ok"] = true; return; }
    if (!Safety::driveAllowed()) { fail(o, Safety::isEstop() ? E_ESTOP : E_NOT_ARMED, "NOT_ARMED"); return; }
    Pump::on(in["speed"] | 100, in["ms"] | 0);
    o["ok"] = true;
  } else if (!strcmp(cmd, "voltage_cap")) {
    float mv = in["max_v"] | 12.0f;
    int cp = in["cap_pct"] | -1;
    Motor::setMaxVoltageLimit(mv, cp);
    o["ok"] = true;
    o["max_v"] = Motor::maxVoltageLimit();
    o["cap_pct"] = Motor::voltageCapPct();
  } else if (!strcmp(cmd, "calibrate")) {
    if (Safety::isArmed()) { fail(o, E_REFUSED, "DISARM_FIRST"); return; }
    if (!Motor::setTrim(in["left_trim"] | 1.0f, in["right_trim"] | 1.0f)) { fail(o, E_INVALID_PARAM, "TRIM_0.5_1.5"); return; }
    o["ok"] = true;
  } else {
    fail(o, E_UNKNOWN_CMD, "UNKNOWN_CMD");
  }
}

void cors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type, X-Pairing-Key");
  server.sendHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Private-Network", "true");
}

void handleApi() {
  JsonDocument in, o;
  String resp;
  if (deserializeJson(in, server.arg("plain"))) {
    o["v"] = PROTOCOL_VERSION; fail(o, E_BAD_JSON, "BAD_JSON");
  } else {
    if (server.hasHeader("X-Pairing-Key")) in["key"] = server.header("X-Pairing-Key");
    process(in, o, false);
  }
  serializeJson(o, resp);
  cors(); server.send(200, "application/json", resp);
}

// Built-in WebRTC & AI Relay Mailbox so Rover Phone <-> Remote Phone need ZERO Termux!
void handleSignal() {
  cors();
  if (server.method() == HTTP_GET) {
    String target = server.arg("for");
    if (target == "rover") {
      server.send(200, "application/json", boxForRover);
      boxForRover = "[]";
    } else if (target == "remote") {
      server.send(200, "application/json", boxForRemote);
      boxForRemote = "[]";
    } else {
      server.send(200, "application/json", sharedAiCfg);
    }
    return;
  }
  // POST: append signal message to target's mailbox
  JsonDocument in;
  if (deserializeJson(in, server.arg("plain"))) {
    server.send(400, "application/json", "{\"ok\":false}"); return;
  }
  const char* to = in["to"] | "";
  if (!strcmp(to, "ai_cfg")) {
    sharedAiCfg = server.arg("plain");
    server.send(200, "application/json", "{\"ok\":true}");
    return;
  }
  String& box = (!strcmp(to, "rover")) ? boxForRover : boxForRemote;
  JsonDocument arr;
  deserializeJson(arr, box);
  if (arr.size() >= 12) arr.remove(0);
  arr.add(in["data"]);
  box = "";
  serializeJson(arr, box);
  server.send(200, "application/json", "{\"ok\":true}");
}


void handleFrame() {
  cors();
  if (server.method() == HTTP_GET) {
    if (latestFrameData.length() == 0 || (millis() - latestFrameMs > 5000)) {
      server.send(204, "text/plain", "");
      return;
    }
    server.send(200, "text/plain", latestFrameData);
    return;
  }
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    if (body.length() > 100 && body.length() < 45000) {
      latestFrameData = body;
      latestFrameMs = millis();
    }
  }
  server.send(200, "application/json", "{\"ok\":true}");
}

void handleSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (serialBuf.length()) {
        JsonDocument in, o; String resp;
        if (deserializeJson(in, serialBuf)) { o["v"] = PROTOCOL_VERSION; fail(o, E_BAD_JSON, "BAD_JSON"); }
        else process(in, o, true);
        serializeJson(o, resp); Serial.println(resp);
        serialBuf = "";
      }
    } else if (serialBuf.length() < 400) serialBuf += c;
    else serialBuf = "";
  }
}

void wifiKeepAlive() {
#if NET_MODE == NET_AP
  return;
#endif
  if (WiFi.status() == WL_CONNECTED) {
    if (!mdnsOn) { mdnsOn = MDNS.begin(MDNS_NAME); Serial.printf("Wi-Fi connected, ESP32 IP: %s\n", WiFi.localIP().toString().c_str()); }
    return;
  }
  mdnsOn = false;
  if (millis() - lastWifiTry >= WIFI_RETRY_MS) { lastWifiTry = millis(); WiFi.begin(WIFI_SSID, WIFI_PASS); }
}
}

namespace Comm {
String savedStaSsid = "";
String savedStaPass = "";

void handleWifiConfig() {
  cors();
  if (server.method() == HTTP_GET) {
    String j = "{\"ok\":true,\"ap_ip\":\"" + WiFi.softAPIP().toString() +
               "\",\"sta_ssid\":\"" + savedStaSsid +
               "\",\"sta_ip\":\"" + WiFi.localIP().toString() +
               "\",\"connected\":" + String(WiFi.status() == WL_CONNECTED ? "true" : "false") + "}";
    server.send(200, "application/json", j);
    return;
  }
  JsonDocument in;
  if (deserializeJson(in, server.arg("plain"))) {
    server.send(400, "application/json", "{\"ok\":false}");
    return;
  }
  savedStaSsid = String(in["ssid"] | "");
  savedStaPass = String(in["pass"] | "");
  Preferences prefs;
  if (prefs.begin("wifi_cfg", false)) {
    prefs.putString("ssid", savedStaSsid);
    prefs.putString("pass", savedStaPass);
    prefs.end();
  }
  if (savedStaSsid.length() == 0) { savedStaSsid = WIFI_SSID; savedStaPass = WIFI_PASS; }
  if (savedStaSsid.length() > 0) {
    WiFi.mode(WIFI_AP_STA);
    WiFi.softAP(AP_SSID, AP_PASS, AP_CHANNEL, 0, 4);
    WiFi.begin(savedStaSsid.c_str(), savedStaPass.c_str());
  } else {
    WiFi.disconnect();
    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASS, AP_CHANNEL, 0, 4);
  }
  server.send(200, "application/json", "{\"ok\":true}");
}

void begin() {
  Preferences prefs;
  if (prefs.begin("wifi_cfg", true)) {
    savedStaSsid = prefs.getString("ssid", WIFI_SSID);
    savedStaPass = prefs.getString("pass", WIFI_PASS);
    prefs.end();
  }
  if (savedStaSsid.length() == 0) { savedStaSsid = WIFI_SSID; savedStaPass = WIFI_PASS; }
  if (savedStaSsid.length() > 0) {
    WiFi.mode(WIFI_AP_STA);
    WiFi.softAP(AP_SSID, AP_PASS, AP_CHANNEL, 0, 4);
    WiFi.setAutoReconnect(true);
    WiFi.begin(savedStaSsid.c_str(), savedStaPass.c_str());
  } else {
    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASS, AP_CHANNEL, 0, 4);
  }
  WiFi.setSleep(false);
  lastWifiTry = millis();
  static const char* hdrs[] = {"X-Pairing-Key"};
  server.collectHeaders(hdrs, 1);
  server.on("/", HTTP_GET, []() { cors(); server.send_P(200, "text/html", WEB_UI); });
  server.on("/api", HTTP_OPTIONS, []() { cors(); server.send(204); });
  server.on("/api", HTTP_POST, handleApi);
  server.on("/signal", HTTP_OPTIONS, []() { cors(); server.send(204); });
  server.on("/signal", HTTP_GET, handleSignal);
  server.on("/signal", HTTP_POST, handleSignal);
  server.on("/frame", HTTP_OPTIONS, []() { cors(); server.send(204); });
  server.on("/frame", HTTP_GET, handleFrame);
  server.on("/frame", HTTP_POST, handleFrame);
  server.on("/wifi", HTTP_OPTIONS, []() { cors(); server.send(204); });
  server.on("/wifi", HTTP_GET, handleWifiConfig);
  server.on("/wifi", HTTP_POST, handleWifiConfig);
  MDNS.begin(MDNS_NAME);
  server.on("/ping", HTTP_GET, []() { cors(); server.send(200, "application/json", "{\"ok\":true,\"v\":" + String(PROTOCOL_VERSION) + "}"); });
  server.onNotFound([]() { cors(); server.send(404, "text/plain", "not found"); });
  server.begin();
}
void update() {
  wifiKeepAlive();
  server.handleClient();
  handleSerial();
}
}
