#pragma once
#include <Arduino.h>
namespace Safety {
enum Reason : uint8_t { BOOT, NONE, ESTOP_SW, ESTOP_HW, COMM_LOSS, DISARMED };
void begin();
void update();
bool arm();
void disarm();
void emergencyStop(Reason r);
bool clearEstop();
void heartbeat();
bool isArmed();
bool isEstop();
bool driveAllowed();
uint32_t heartbeatAgeMs();
Reason lastReason();
const char* reasonName();
void setSeqBase(long s);
bool checkSeq(long s);
}
