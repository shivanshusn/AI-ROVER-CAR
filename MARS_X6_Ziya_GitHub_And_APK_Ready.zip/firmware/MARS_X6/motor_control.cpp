#include "motor_control.h"
#include "config.h"
#include "pins.h"
#include "light_control.h"
#include "servo_control.h"
#include "pump_control.h"
#include <Preferences.h>
#include "pwm_compat.h"

namespace {
const int MAXD = (1 << MOTOR_PWM_BITS) - 1;
// Single L298N: Ch A (ENA=25, IN1=16, IN2=17) = Left Side Motors
//               Ch B (ENB=14, IN3=32, IN4=33) = Right Side Motors
int curL = 0, curR = 0;
int tgtL = 0, tgtR = 0;
uint8_t limitPct = 100;
float trimL = 1.0f, trimR = 1.0f;
float userMaxV = 12.0f;
int userManualCapPct = 100;
float capFrac = 1.0f;
bool capDirty = false, braking = false;
uint32_t lastRamp = 0;

uint8_t stuntId = 0;
uint32_t stuntStart = 0;
int stuntSpeed = 85;

int maxDuty() {
  return max(MOTOR_MIN_PWM + 10, (int)(MAXD * capFrac));
}

void writeCh(uint8_t enPin, uint8_t pwmCh, uint8_t inA, uint8_t inB, int pct) {
  if (abs(pct) < 3) {
    digitalWrite(inA, LOW);
    digitalWrite(inB, LOW);
    PwmCompat::write(enPin, pwmCh, 0);
    return;
  }
  digitalWrite(inA, pct > 0 ? HIGH : LOW);
  digitalWrite(inB, pct > 0 ? LOW : HIGH);
  int duty = map(constrain(abs(pct), 1, 100), 1, 100, MOTOR_MIN_PWM, maxDuty());
  PwmCompat::write(enPin, pwmCh, duty);
}

void apply() {
  writeCh(Pins::L298_ENA, 0, Pins::L298_IN1, Pins::L298_IN2, curL);
  digitalWrite(Pins::L298_IN1_ALT, digitalRead(Pins::L298_IN1));
  digitalWrite(Pins::L298_IN2_ALT, digitalRead(Pins::L298_IN2));
  writeCh(Pins::L298_ENB, 1, Pins::L298_IN3, Pins::L298_IN4, curR);
}

void brakeCh(uint8_t enPin, uint8_t pwmCh, uint8_t inA, uint8_t inB) {
  digitalWrite(inA, HIGH);
  digitalWrite(inB, HIGH);
  PwmCompat::write(enPin, pwmCh, MAXD);
}

int stepVal(int c, int t) {
  if (abs(t - c) <= MOTOR_RAMP_STEP) return t;
  return c < t ? c + MOTOR_RAMP_STEP : c - MOTOR_RAMP_STEP;
}

void setRawLR(int l, int r) {
  braking = false;
  tgtL = constrain((int)(l * limitPct / 100.0f * trimL), -100, 100);
  tgtR = constrain((int)(r * limitPct / 100.0f * trimR), -100, 100);
  // Apply immediately on first command so there is zero lag!
  curL = stepVal(curL, tgtL);
  curR = stepVal(curR, tgtR);
  apply();
}

void updateStunt() {
  if (!stuntId) return;
  uint32_t el = millis() - stuntStart;
  int s = stuntSpeed;
  if (stuntId == 1) { // Tornado 360 Spin on 1x L298N
    Lights::setMode(3);
    if (el < 1400) setRawLR(s, -s);
    else if (el < 1700) setRawLR(0, 0);
    else if (el < 3100) setRawLR(-s, s);
    else { Lights::setMode(0); stuntId = 0; setRawLR(0, 0); }
  } else if (stuntId == 2) { // Naagin Slalom Dance
    Lights::setMode(2);
    uint32_t phase = (el / 550) % 4;
    if (el > 4400) { Lights::setMode(0); Servos::camCenter(); stuntId = 0; setRawLR(0, 0); return; }
    if (phase == 0) { setRawLR(s, s / 4); Servos::camPan(130); }
    else if (phase == 1) { setRawLR(s / 4, s); Servos::camPan(50); }
    else if (phase == 2) { setRawLR(-s, -s / 4); Servos::camPan(120); }
    else { setRawLR(-s / 4, -s); Servos::camPan(60); }
  } else if (stuntId == 3) { // Burnout Launch
    Lights::setHazard(true);
    if (el < 700) setRawLR(-s, s);
    else if (el < 2200) setRawLR(100, 100);
    else { Lights::setHazard(false); stuntId = 0; setRawLR(0, 0); }
  } else if (stuntId == 4) { // Sand Shake
    uint32_t p = (el / 220) % 2;
    if (el > 2600) { stuntId = 0; setRawLR(0, 0); return; }
    if (p == 0) setRawLR(s, -s / 2);
    else setRawLR(-s, s / 2);
  } else if (stuntId == 5) { // Kisan Spray Patrol
    if (el > 5000) { Pump::off(); Servos::camCenter(); Lights::setMode(0); stuntId = 0; setRawLR(0, 0); return; }
    Lights::setHead(true);
    if (!Pump::isOn()) Pump::on(85, 5000);
    setRawLR(60, 60);
    Servos::camPan(((el / 700) % 2 == 0) ? 60 : 120);
  }
}
}

namespace Motor {
void begin() {
  const uint8_t pins[] = {
    Pins::L298_ENA, Pins::L298_IN1, Pins::L298_IN2,
    Pins::L298_IN1_ALT, Pins::L298_IN2_ALT,
    Pins::L298_IN3, Pins::L298_IN4, Pins::L298_ENB
  };
  for (uint8_t pin : pins) {
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
  }
  PwmCompat::attach(Pins::L298_ENA, 0, MOTOR_PWM_FREQ, MOTOR_PWM_BITS);
  PwmCompat::attach(Pins::L298_ENB, 1, MOTOR_PWM_FREQ, MOTOR_PWM_BITS);

  Preferences prefs;
  if (prefs.begin("motor", true)) {
    trimL = prefs.getFloat("tl", 1.0f);
    trimR = prefs.getFloat("tr", 1.0f);
    userMaxV = prefs.getFloat("maxv", 12.0f);
    userManualCapPct = prefs.getInt("cappct", 100);
    prefs.end();
  }
  capFrac = constrain(userManualCapPct / 100.0f, 0.35f, 1.0f);
  stopNow();
}

void update() {
  updateStunt();
  if (braking) return;
  uint32_t now = millis();
  if (now - lastRamp < MOTOR_RAMP_INTERVAL_MS) return;
  lastRamp = now;
  bool changed = capDirty;
  capDirty = false;
  if (curL != tgtL) { curL = stepVal(curL, tgtL); changed = true; }
  if (curR != tgtR) { curR = stepVal(curR, tgtR); changed = true; }
  if (changed) apply();
}

void drive(int left, int right) {
  stuntId = 0;
  setRawLR(left, right);
}

void driveQuad(int lf, int lr, int rf, int rr) {
  stuntId = 0;
  setRawLR((lf + lr) / 2, (rf + rr) / 2);
}

void arcTurn(int baseSpeed, int dir, int turnIntensity) {
  stuntId = 0;
  int b = constrain(baseSpeed, -100, 100);
  int ti = constrain(turnIntensity, 10, 100);
  if (abs(b) < 8) {
    int sp = max(65, ti);
    if (dir < 0) setRawLR(-sp / 2, sp);
    else if (dir > 0) setRawLR(sp, -sp / 2);
    else setRawLR(0, 0);
    return;
  }
  float ratio = 1.0f - (ti / 100.0f) * (1.0f - TURN_INNER_FRONT_RATIO);
  int inner = (int)(b * ratio);
  if (dir < 0) setRawLR(inner, b);      // Left Turn: Left channel slows, Right channel full
  else if (dir > 0) setRawLR(b, inner); // Right Turn: Left channel full, Right channel slows
  else setRawLR(b, b);
}

void spin(int dir, int speed) {
  stuntId = 0;
  int s = constrain(abs(speed), 35, 100);
  if (dir > 0) setRawLR(s, -s);       // CW Spin
  else if (dir < 0) setRawLR(-s, s);  // CCW Spin
  else setRawLR(0, 0);
}

bool startStunt(const char* name, int speed) {
  stuntSpeed = constrain(speed, 50, 100);
  stuntStart = millis();
  if (!strcmp(name, "tornado")) stuntId = 1;
  else if (!strcmp(name, "snake")) stuntId = 2;
  else if (!strcmp(name, "burnout")) stuntId = 3;
  else if (!strcmp(name, "shake")) stuntId = 4;
  else if (!strcmp(name, "spray_patrol")) stuntId = 5;
  else if (!strcmp(name, "stop")) { stuntId = 0; stopNow(); return true; }
  else return false;
  return true;
}

const char* activeStunt() {
  switch (stuntId) {
    case 1: return "tornado";
    case 2: return "snake";
    case 3: return "burnout";
    case 4: return "shake";
    case 5: return "spray_patrol";
    default: return "none";
  }
}

void stop() {
  stuntId = 0;
  braking = false;
  tgtL = tgtR = 0;
}

void stopNow() {
  stuntId = 0;
  braking = false;
  tgtL = tgtR = curL = curR = 0;
  apply();
}

void brake() {
  stuntId = 0;
  tgtL = tgtR = curL = curR = 0;
  braking = true;
  brakeCh(Pins::L298_ENA, 0, Pins::L298_IN1, Pins::L298_IN2);
  digitalWrite(Pins::L298_IN1_ALT, HIGH);
  digitalWrite(Pins::L298_IN2_ALT, HIGH);
  brakeCh(Pins::L298_ENB, 1, Pins::L298_IN3, Pins::L298_IN4);
}

void setSpeedLimit(uint8_t pct) { limitPct = constrain(pct, 10, 100); }

void setMaxVoltageLimit(float maxV, int manualCapPct) {
  userMaxV = constrain(maxV, 4.5f, 12.6f);
  if (manualCapPct >= 30 && manualCapPct <= 100) {
    userManualCapPct = manualCapPct;
  } else {
    userManualCapPct = constrain((int)roundf((userMaxV / 12.0f) * 100.0f), 35, 100);
  }
  capFrac = userManualCapPct / 100.0f;
  capDirty = true;
  Preferences prefs;
  if (prefs.begin("motor", false)) {
    prefs.putFloat("maxv", userMaxV);
    prefs.putInt("cappct", userManualCapPct);
    prefs.end();
  }
  apply();
}

float maxVoltageLimit() { return userMaxV; }

void setSupplyVoltage(float voltage) {
  // Respect user's manual voltage cap selection directly so 12V means 100% PWM!
  (void)voltage;
  float next = constrain(userManualCapPct / 100.0f, 0.35f, 1.0f);
  if (fabsf(next - capFrac) > 0.01f) { capFrac = next; capDirty = true; }
}

int voltageCapPct() { return (int)roundf(capFrac * 100.0f); }

bool setTrim(float left, float right) {
  if (left < 0.5f || left > 1.5f || right < 0.5f || right > 1.5f) return false;
  trimL = left; trimR = right;
  Preferences prefs;
  if (prefs.begin("motor", false)) {
    prefs.putFloat("tl", left); prefs.putFloat("tr", right); prefs.end();
  }
  return true;
}

float trimLeft() { return trimL; }
float trimRight() { return trimR; }
int left() { return curL; }
int right() { return curR; }
int leftFront() { return curL; }
int leftRear() { return curL; }
int rightFront() { return curR; }
int rightRear() { return curR; }
bool isBraking() { return braking; }
}
