#include "light_control.h"
#include "config.h"
#include "pins.h"

namespace {
const uint8_t P[4] = {Pins::LIGHT_FL, Pins::LIGHT_FR, Pins::LIGHT_RL, Pins::LIGHT_RR};
uint8_t userMask = 0;
uint8_t fxMode = 0; // 0=normal, 1=hazard, 2=police, 3=disco
uint8_t stepIdx = 0;
uint32_t lastToggle = 0;
void write(uint8_t m) { for (int i = 0; i < 4; i++) digitalWrite(P[i], (m >> i) & 1); }
}

namespace Lights {
void begin() { for (int i = 0; i < 4; i++) { pinMode(P[i], OUTPUT); digitalWrite(P[i], LOW); } }
void update() {
  if (fxMode == 0) { write(userMask); return; }
  uint32_t now = millis();
  uint32_t period = (fxMode == 1) ? HAZARD_PERIOD_MS : (fxMode == 2 ? 160 : 120);
  if (now - lastToggle >= period) { lastToggle = now; stepIdx = (stepIdx + 1) % 4; }
  if (fxMode == 1) write((stepIdx % 2 == 0) ? 0x0F : 0x00);
  else if (fxMode == 2) write((stepIdx % 2 == 0) ? 0x05 : 0x0A); // Left (FL+RL) vs Right (FR+RR)
  else if (fxMode == 3) write(1 << stepIdx);                     // 4-corner chase
}
void set(uint8_t i, bool on) { if (i > 3) return; fxMode = 0; if (on) userMask |= (1 << i); else userMask &= ~(1 << i); }
void setHead(bool on) { fxMode = 0; if (on) userMask |= 0x03; else userMask &= ~0x03; }
void setTail(bool on) { fxMode = 0; if (on) userMask |= 0x0C; else userMask &= ~0x0C; }
void setAll(bool on) { fxMode = 0; userMask = on ? 0x0F : 0x00; }
void setHazard(bool on) { fxMode = on ? 1 : 0; stepIdx = 0; lastToggle = millis(); }
void setMode(uint8_t m) { fxMode = m > 3 ? 0 : m; stepIdx = 0; lastToggle = millis(); }
uint8_t mode() { return fxMode; }
uint8_t mask() { return userMask; }
bool hazard() { return fxMode == 1; }
}
