#pragma once
#include <Arduino.h>

namespace Pins {
// ============================================================================
// 30-PIN ESP32 DEVKIT V1 (D-LABELED PINS) — 1x L298N MODULE
// All 6 L298N pins sit together on the LEFT row of the 30-pin ESP32:
// D25, D26, D27, D32, D33, D14!
// (IN1/IN2 also mirror to GPIO 16/17 RX2/TX2 for backward compatibility)
// ============================================================================
constexpr uint8_t L298_ENA     = 25; // Board label: D25 -> L298N ENA (Left Speed PWM)
constexpr uint8_t L298_IN1     = 26; // Board label: D26 -> L298N IN1 (Left Dir 1)
constexpr uint8_t L298_IN2     = 27; // Board label: D27 -> L298N IN2 (Left Dir 2)
constexpr uint8_t L298_IN3     = 32; // Board label: D32 -> L298N IN3 (Right Dir 1)
constexpr uint8_t L298_IN4     = 33; // Board label: D33 -> L298N IN4 (Right Dir 2)
constexpr uint8_t L298_ENB     = 14; // Board label: D14 -> L298N ENB (Right Speed PWM)

// Mirror pins if user wired IN1/IN2 to RX2 (16) / TX2 (17)
constexpr uint8_t L298_IN1_ALT = 16; // Board label: RX2
constexpr uint8_t L298_IN2_ALT = 17; // Board label: TX2

// ============================================================================
// SERVOS, 4x LEDs, SUBMERSIBLE PUMP, BATTERY ADC (ALL 30-PIN D-LABELS)
// ============================================================================
constexpr uint8_t SERVO_CARGO = 18; // Board label: D18 -> Servo 1 (Cargo / Spray Arm)
constexpr uint8_t SERVO_CAM   = 19; // Board label: D19 -> Servo 2 (Camera Pan Mount)
constexpr uint8_t PUMP        = 21; // Board label: D21 -> Submersible Pump MOSFET Gate
constexpr uint8_t LIGHT_FL    = 4;  // Board label: D4  -> Front-Left LED
constexpr uint8_t LIGHT_FR    = 13; // Board label: D13 -> Front-Right LED
constexpr uint8_t LIGHT_RL    = 22; // Board label: D22 -> Rear-Left LED
constexpr uint8_t LIGHT_RR    = 23; // Board label: D23 -> Rear-Right LED
constexpr uint8_t US_TRIG     = 5;  // Board label: D5
constexpr uint8_t US_ECHO     = 35; // Board label: D35 (Input-only)
constexpr uint8_t AUDIO       = 2;  // Board label: D2
constexpr uint8_t BATT_ADC    = 34; // Board label: D34 (3S Battery Divider Input)
constexpr uint8_t ESTOP       = 36; // Board label: VP  (Input-only)
}
