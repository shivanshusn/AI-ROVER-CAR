#include "pump_control.h"
#include "config.h"
#include "pins.h"
#include "pwm_compat.h"
namespace {
const int MAXD = (1 << PUMP_PWM_BITS) - 1;
bool active = false; int pct = 0; uint32_t until = 0; float capFrac = 0.45f;
void write() { PwmCompat::write(Pins::PUMP, 2, active ? (int)(MAXD * capFrac * pct / 100.0f) : 0); }
}
namespace Pump {
void begin() {
#if PUMP_ENABLED
  PwmCompat::attach(Pins::PUMP, 2, PUMP_PWM_FREQ, PUMP_PWM_BITS);
  PwmCompat::write(Pins::PUMP, 2, 0);
#endif
}
void on(int p, uint32_t ms) {
#if PUMP_ENABLED
  pct = constrain(p, 10, 100);
  if (ms == 0 || ms > PUMP_MAX_RUN_MS) ms = PUMP_MAX_RUN_MS;
  until = millis() + ms; active = true; write();
#endif
}
void off() {
#if PUMP_ENABLED
  active = false; write();
#endif
}
void update() { if (active && (int32_t)(millis() - until) >= 0) off(); }
bool isOn() { return active; }
int percent() { return active ? pct : 0; }
bool enabled() { return PUMP_ENABLED; }
void setBatteryVoltage(float v) {
  float supply = PUMP_SUPPLY_V > 0 ? PUMP_SUPPLY_V : v;
  float n = (supply < 4.0f) ? 0.45f : constrain(PUMP_RATED_V / supply, 0.2f, 1.0f);
  if (fabsf(n - capFrac) > 0.01f) { capFrac = n; if (active) write(); }
}
}
