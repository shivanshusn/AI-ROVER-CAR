#pragma once
#include <Arduino.h>

namespace Motor {
void begin();
void update();
void drive(int left, int right);                   // Left & Right side (-100..100)
void driveQuad(int lf, int lr, int rf, int rr);    // 4-channel independent (-100..100)
void arcTurn(int baseSpeed, int dir, int turnIntensity = 70); // dir: -1=left, +1=right
void spin(int dir, int speed);                     // dir: -1=CCW, +1=CW
bool startStunt(const char* name, int speed = 75); // "tornado","snake","burnout","shake","spray_patrol"
const char* activeStunt();
void stop();
void stopNow();
void brake();
void setSpeedLimit(uint8_t pct);
void setMaxVoltageLimit(float maxV, int manualCapPct = -1); // User-controlled 5V..12V+ cap from UI!
float maxVoltageLimit();
void setSupplyVoltage(float packV);
int voltageCapPct();
bool setTrim(float l, float r);
float trimLeft();
float trimRight();
int left();
int right();
int leftFront();
int leftRear();
int rightFront();
int rightRear();
bool isBraking();
}
