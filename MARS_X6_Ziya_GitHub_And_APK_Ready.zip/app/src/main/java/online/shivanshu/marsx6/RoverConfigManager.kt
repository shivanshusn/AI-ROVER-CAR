package online.shivanshu.marsx6

import android.content.Context
import org.json.JSONObject

class RoverConfigManager(context: Context) {
    private val prefs = context.getSharedPreferences("mars_x6_ziya_prefs", Context.MODE_PRIVATE)

    fun getAllConfigJson(): String {
        val obj = JSONObject()
        obj.put("roverName", prefs.getString("roverName", "MARS-X6") ?: "MARS-X6")
        obj.put("botName", prefs.getString("botName", "Ziya") ?: "Ziya")
        obj.put("geminiLiveModel", prefs.getString("geminiLiveModel", "models/gemini-3.8-live") ?: "models/gemini-3.8-live")
        obj.put("apiKey", prefs.getString("apiKey", "") ?: "")
        obj.put("espUrl", prefs.getString("espUrl", "http://192.168.4.1") ?: "http://192.168.4.1")
        return obj.toString()
    }

    fun saveConfigJson(jsonStr: String) {
        val obj = JSONObject(jsonStr)
        val ed = prefs.edit()
        if (obj.has("roverName")) ed.putString("roverName", obj.getString("roverName"))
        if (obj.has("botName")) ed.putString("botName", obj.getString("botName"))
        if (obj.has("geminiLiveModel")) ed.putString("geminiLiveModel", obj.getString("geminiLiveModel"))
        if (obj.has("apiKey")) ed.putString("apiKey", obj.getString("apiKey"))
        if (obj.has("espUrl")) ed.putString("espUrl", obj.getString("espUrl"))
        ed.apply()
    }
}
